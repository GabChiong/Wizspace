/* WIZSPACE - a Final Project of ITCC 11 A2 - Event Driven Programming
 * by
 * Mark Gabriel C. Chiong
 * Rio Gwyneth Soliva
 * Deon Bryze Barberan
 * of BSIT 2 XUCCS
 */
package wizspa;


import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

public class Wizspace extends javax.swing.JFrame {
    
    Connection con;
    String Year = "";
    String Course = "";
    String Gender = "";
    /**
     * Creates new form called Wizspace
     */
    public Wizspace() {
        initComponents();
        createConnection();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * avoid modifications.
     * 
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        login = new javax.swing.JPanel();
        btnCreateAcc = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        loginunameTF = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        loginpasswordTF = new javax.swing.JPasswordField();
        btnLogin = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel48 = new javax.swing.JLabel();
        createacc = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel49 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        unameTF = new javax.swing.JTextField();
        passwordTF = new javax.swing.JTextField();
        xuemailTF = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        firstnameTF = new javax.swing.JTextField();
        lastnameTF = new javax.swing.JTextField();
        ageTF = new javax.swing.JTextField();
        addressTF = new javax.swing.JTextField();
        contactnoTF = new javax.swing.JTextField();
        btnSubmit = new javax.swing.JButton();
        jLabel15 = new javax.swing.JLabel();
        middleinitialTF = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        btnMale = new javax.swing.JButton();
        btnFemale = new javax.swing.JButton();
        btnYearI = new javax.swing.JButton();
        btnYearII = new javax.swing.JButton();
        btnYearIII = new javax.swing.JButton();
        btnYearIV = new javax.swing.JButton();
        btnBSCS = new javax.swing.JButton();
        btnBSIS = new javax.swing.JButton();
        btnBSIT = new javax.swing.JButton();
        home = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jLabel53 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        contactno = new javax.swing.JLabel();
        xuemail = new javax.swing.JLabel();
        course = new javax.swing.JLabel();
        year = new javax.swing.JLabel();
        address = new javax.swing.JLabel();
        age = new javax.swing.JLabel();
        name = new javax.swing.JLabel();
        FillupFailed = new javax.swing.JPanel();
        jLabel27 = new javax.swing.JLabel();
        jButton4 = new javax.swing.JButton();
        LoginFailed = new javax.swing.JPanel();
        jLabel28 = new javax.swing.JLabel();
        jButton5 = new javax.swing.JButton();
        jLabel29 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        CSSC = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jLabel51 = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        jButton6 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        jLabel31 = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        jButton7 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jLabel35 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        CCSAdmin = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        jLabel52 = new javax.swing.JLabel();
        jLabel39 = new javax.swing.JLabel();
        jLabel40 = new javax.swing.JLabel();
        jButton10 = new javax.swing.JButton();
        jButton11 = new javax.swing.JButton();
        jLabel41 = new javax.swing.JLabel();
        jLabel42 = new javax.swing.JLabel();
        jButton12 = new javax.swing.JButton();
        jButton13 = new javax.swing.JButton();
        jLabel43 = new javax.swing.JLabel();
        jLabel44 = new javax.swing.JLabel();
        jLabel45 = new javax.swing.JLabel();
        jLabel46 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new java.awt.CardLayout());

        login.setBackground(new java.awt.Color(37, 37, 37));

        btnCreateAcc.setBackground(new java.awt.Color(37, 37, 37));
        btnCreateAcc.setForeground(new java.awt.Color(106, 195, 161));
        btnCreateAcc.setText("Create Account");
        btnCreateAcc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCreateAccActionPerformed(evt);
            }
        });

        jLabel1.setBackground(new java.awt.Color(106, 195, 161));
        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(106, 195, 161));
        jLabel1.setText("USERNAME:");
        jLabel1.setToolTipText("");

        loginunameTF.setBackground(new java.awt.Color(37, 37, 37));
        loginunameTF.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        loginunameTF.setForeground(new java.awt.Color(255, 255, 255));
        loginunameTF.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(106, 195, 161)));

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(106, 195, 161));
        jLabel2.setText("PASSWORD:");

        loginpasswordTF.setBackground(new java.awt.Color(37, 37, 37));
        loginpasswordTF.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        loginpasswordTF.setForeground(new java.awt.Color(255, 255, 255));
        loginpasswordTF.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(106, 195, 161)));

        btnLogin.setBackground(new java.awt.Color(37, 37, 37));
        btnLogin.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnLogin.setForeground(new java.awt.Color(106, 195, 161));
        btnLogin.setText("Login");
        btnLogin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLoginActionPerformed(evt);
            }
        });

        jPanel2.setBackground(new java.awt.Color(106, 195, 161));

        jLabel48.setBackground(new java.awt.Color(106, 195, 161));
        jLabel48.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Sizes.png"))); // NOI18N
        jLabel48.setText("jLabel48");
        jLabel48.setOpaque(true);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel48, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(23, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(79, 79, 79)
                .addComponent(jLabel48, javax.swing.GroupLayout.PREFERRED_SIZE, 245, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout loginLayout = new javax.swing.GroupLayout(login);
        login.setLayout(loginLayout);
        loginLayout.setHorizontalGroup(
            loginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(loginLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnCreateAcc)
                .addContainerGap())
            .addGroup(loginLayout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(loginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(jLabel1)
                    .addGroup(loginLayout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addGroup(loginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(btnLogin)
                            .addGroup(loginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(loginpasswordTF, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(loginunameTF, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addGap(0, 64, Short.MAX_VALUE))
        );
        loginLayout.setVerticalGroup(
            loginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(loginLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnCreateAcc)
                .addGap(75, 75, 75)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(loginunameTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(loginpasswordTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnLogin)
                .addContainerGap(180, Short.MAX_VALUE))
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        getContentPane().add(login, "card3");

        createacc.setBackground(new java.awt.Color(37, 37, 37));

        jPanel3.setBackground(new java.awt.Color(106, 195, 161));

        jLabel49.setBackground(new java.awt.Color(106, 195, 161));
        jLabel49.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Sizes.png"))); // NOI18N
        jLabel49.setText("jLabel48");
        jLabel49.setOpaque(true);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel49, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(23, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(78, 78, 78)
                .addComponent(jLabel49, javax.swing.GroupLayout.PREFERRED_SIZE, 245, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(106, 195, 161));
        jLabel3.setText("CREATE ACCOUNT:");

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(106, 195, 161));
        jLabel4.setText("USERNAME:");

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(106, 195, 161));
        jLabel5.setText("PASSWORD:");

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(106, 195, 161));
        jLabel6.setText("XU EMAIL:");

        unameTF.setBackground(new java.awt.Color(37, 37, 37));
        unameTF.setForeground(new java.awt.Color(255, 255, 255));
        unameTF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                unameTFActionPerformed(evt);
            }
        });

        passwordTF.setBackground(new java.awt.Color(37, 37, 37));
        passwordTF.setForeground(new java.awt.Color(255, 255, 255));
        passwordTF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                passwordTFActionPerformed(evt);
            }
        });

        xuemailTF.setBackground(new java.awt.Color(37, 37, 37));
        xuemailTF.setForeground(new java.awt.Color(255, 255, 255));
        xuemailTF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                xuemailTFActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(106, 195, 161));
        jLabel7.setText("PERSONAL INFORMATION:");

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(106, 195, 161));
        jLabel8.setText("FIRST NAME:");

        jLabel9.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(106, 195, 161));
        jLabel9.setText("LAST NAME:");

        jLabel10.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(106, 195, 161));
        jLabel10.setText("AGE:");

        jLabel11.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(106, 195, 161));
        jLabel11.setText("ADDRESS:");

        jLabel12.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(106, 195, 161));
        jLabel12.setText("YEAR");

        jLabel13.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(106, 195, 161));
        jLabel13.setText("COURSE:");

        jLabel14.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(106, 195, 161));
        jLabel14.setText("CONTACT NO.:");

        firstnameTF.setBackground(new java.awt.Color(37, 37, 37));
        firstnameTF.setForeground(new java.awt.Color(106, 195, 161));
        firstnameTF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                firstnameTFActionPerformed(evt);
            }
        });

        lastnameTF.setBackground(new java.awt.Color(37, 37, 37));
        lastnameTF.setForeground(new java.awt.Color(106, 195, 161));

        ageTF.setBackground(new java.awt.Color(37, 37, 37));
        ageTF.setForeground(new java.awt.Color(106, 195, 161));

        addressTF.setBackground(new java.awt.Color(37, 37, 37));
        addressTF.setForeground(new java.awt.Color(106, 195, 161));

        contactnoTF.setBackground(new java.awt.Color(37, 37, 37));
        contactnoTF.setForeground(new java.awt.Color(106, 195, 161));

        btnSubmit.setBackground(new java.awt.Color(37, 37, 37));
        btnSubmit.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnSubmit.setForeground(new java.awt.Color(106, 195, 161));
        btnSubmit.setText("SUBMIT");
        btnSubmit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSubmitActionPerformed(evt);
            }
        });

        jLabel15.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(106, 195, 161));
        jLabel15.setText("M.I.");

        middleinitialTF.setBackground(new java.awt.Color(37, 37, 37));
        middleinitialTF.setForeground(new java.awt.Color(106, 195, 161));

        jLabel16.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(106, 195, 161));
        jLabel16.setText("GENDER:");

        btnMale.setBackground(new java.awt.Color(0, 61, 91));
        btnMale.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnMale.setForeground(java.awt.Color.white);
        btnMale.setText("M");
        btnMale.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMaleActionPerformed(evt);
            }
        });

        btnFemale.setBackground(new java.awt.Color(209, 73, 91));
        btnFemale.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnFemale.setForeground(java.awt.Color.white);
        btnFemale.setText("F");
        btnFemale.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFemaleActionPerformed(evt);
            }
        });

        btnYearI.setBackground(new java.awt.Color(37, 37, 37));
        btnYearI.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnYearI.setForeground(new java.awt.Color(106, 195, 161));
        btnYearI.setText("I");
        btnYearI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnYearIActionPerformed(evt);
            }
        });

        btnYearII.setBackground(new java.awt.Color(37, 37, 37));
        btnYearII.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnYearII.setForeground(new java.awt.Color(106, 195, 161));
        btnYearII.setText("II");
        btnYearII.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnYearIIActionPerformed(evt);
            }
        });

        btnYearIII.setBackground(new java.awt.Color(37, 37, 37));
        btnYearIII.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnYearIII.setForeground(new java.awt.Color(106, 195, 161));
        btnYearIII.setText("III");
        btnYearIII.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnYearIIIActionPerformed(evt);
            }
        });

        btnYearIV.setBackground(new java.awt.Color(37, 37, 37));
        btnYearIV.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnYearIV.setForeground(new java.awt.Color(106, 195, 161));
        btnYearIV.setText("IV");
        btnYearIV.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnYearIVActionPerformed(evt);
            }
        });

        btnBSCS.setBackground(new java.awt.Color(37, 37, 37));
        btnBSCS.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnBSCS.setForeground(new java.awt.Color(106, 195, 161));
        btnBSCS.setText("BSCS");
        btnBSCS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBSCSActionPerformed(evt);
            }
        });

        btnBSIS.setBackground(new java.awt.Color(37, 37, 37));
        btnBSIS.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnBSIS.setForeground(new java.awt.Color(106, 195, 161));
        btnBSIS.setText("BSIS");
        btnBSIS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBSISActionPerformed(evt);
            }
        });

        btnBSIT.setBackground(new java.awt.Color(37, 37, 37));
        btnBSIT.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnBSIT.setForeground(new java.awt.Color(106, 195, 161));
        btnBSIT.setText("BSIT");
        btnBSIT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBSITActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout createaccLayout = new javax.swing.GroupLayout(createacc);
        createacc.setLayout(createaccLayout);
        createaccLayout.setHorizontalGroup(
            createaccLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(createaccLayout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(createaccLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(createaccLayout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jLabel3))
                    .addGroup(createaccLayout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(unameTF, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(createaccLayout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jLabel7))
                    .addGroup(createaccLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(createaccLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(createaccLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(btnSubmit)
                                .addGroup(createaccLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(createaccLayout.createSequentialGroup()
                                        .addComponent(jLabel9)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(lastnameTF, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(createaccLayout.createSequentialGroup()
                                        .addComponent(jLabel12)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(btnYearI)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnYearII)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnYearIII)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnYearIV))
                                    .addGroup(createaccLayout.createSequentialGroup()
                                        .addComponent(jLabel13)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnBSCS)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnBSIS)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnBSIT))
                                    .addGroup(createaccLayout.createSequentialGroup()
                                        .addComponent(jLabel14)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(contactnoTF))
                                    .addGroup(createaccLayout.createSequentialGroup()
                                        .addComponent(jLabel6)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(xuemailTF, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(createaccLayout.createSequentialGroup()
                                        .addComponent(jLabel5)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(passwordTF, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(createaccLayout.createSequentialGroup()
                                        .addGroup(createaccLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, createaccLayout.createSequentialGroup()
                                                .addComponent(jLabel10)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(ageTF))
                                            .addComponent(jLabel11, javax.swing.GroupLayout.Alignment.LEADING))
                                        .addGroup(createaccLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(createaccLayout.createSequentialGroup()
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(addressTF))
                                            .addGroup(createaccLayout.createSequentialGroup()
                                                .addGap(13, 13, 13)
                                                .addComponent(jLabel16)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(btnMale)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(btnFemale)
                                                .addGap(0, 0, Short.MAX_VALUE))))))
                            .addGroup(createaccLayout.createSequentialGroup()
                                .addComponent(jLabel8)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(firstnameTF, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel15)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(middleinitialTF, javax.swing.GroupLayout.DEFAULT_SIZE, 58, Short.MAX_VALUE)))))
                .addContainerGap(45, Short.MAX_VALUE))
        );
        createaccLayout.setVerticalGroup(
            createaccLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(createaccLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(createaccLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(unameTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(createaccLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(passwordTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(createaccLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(xuemailTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(createaccLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(firstnameTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel15)
                    .addComponent(middleinitialTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(createaccLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(lastnameTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(createaccLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(ageTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel16)
                    .addComponent(btnMale)
                    .addComponent(btnFemale))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(createaccLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(addressTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(createaccLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12)
                    .addComponent(btnYearI)
                    .addComponent(btnYearII)
                    .addComponent(btnYearIII)
                    .addComponent(btnYearIV))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(createaccLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13)
                    .addComponent(btnBSCS)
                    .addComponent(btnBSIS)
                    .addComponent(btnBSIT))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(createaccLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel14)
                    .addComponent(contactnoTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(btnSubmit)
                .addContainerGap(31, Short.MAX_VALUE))
        );

        getContentPane().add(createacc, "card3");

        jPanel4.setBackground(new java.awt.Color(106, 195, 161));

        jLabel53.setBackground(new java.awt.Color(106, 195, 161));
        jLabel53.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Sizes.png"))); // NOI18N
        jLabel53.setText("jLabel48");
        jLabel53.setOpaque(true);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel53, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(36, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(79, 79, 79)
                .addComponent(jLabel53, javax.swing.GroupLayout.PREFERRED_SIZE, 245, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(113, Short.MAX_VALUE))
        );

        jPanel1.setBackground(new java.awt.Color(37, 37, 37));
        jPanel1.setPreferredSize(new java.awt.Dimension(566, 437));

        jLabel17.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(106, 195, 161));
        jLabel17.setText("STUDENT INFORMATION");

        jLabel18.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(106, 195, 161));
        jLabel18.setText("NAME:");

        jLabel19.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(106, 195, 161));
        jLabel19.setText("AGE:");

        jLabel20.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(106, 195, 161));
        jLabel20.setText("ADDRESS:");

        jLabel21.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(106, 195, 161));
        jLabel21.setText("YEAR:");

        jLabel22.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(106, 195, 161));
        jLabel22.setText("COURSE:");

        jLabel23.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(106, 195, 161));
        jLabel23.setText("CONTACT NO.:");

        jLabel24.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel24.setForeground(new java.awt.Color(106, 195, 161));
        jLabel24.setText("XU EMAIL:");

        jLabel25.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel25.setForeground(new java.awt.Color(106, 195, 161));
        jLabel25.setText("CSSC UPDATES:");

        jLabel26.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel26.setForeground(new java.awt.Color(106, 195, 161));
        jLabel26.setText("CCS ADMIN UPDATES:");

        jButton1.setBackground(new java.awt.Color(106, 195, 161));
        jButton1.setForeground(new java.awt.Color(37, 37, 37));
        jButton1.setText("CSSC UPDATES");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setBackground(new java.awt.Color(106, 195, 161));
        jButton2.setForeground(new java.awt.Color(37, 37, 37));
        jButton2.setText("ADMIN UPDATES");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setBackground(new java.awt.Color(37, 37, 37));
        jButton3.setForeground(new java.awt.Color(106, 195, 161));
        jButton3.setText("Logout");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        contactno.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        contactno.setForeground(new java.awt.Color(255, 255, 255));

        xuemail.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        xuemail.setForeground(new java.awt.Color(255, 255, 255));

        course.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        course.setForeground(new java.awt.Color(255, 255, 255));

        year.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        year.setForeground(new java.awt.Color(255, 255, 255));

        address.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        address.setForeground(new java.awt.Color(255, 255, 255));

        age.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        age.setForeground(new java.awt.Color(255, 255, 255));

        name.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        name.setForeground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel17)
                    .addComponent(jLabel25)
                    .addComponent(jLabel26)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel23)
                            .addComponent(jLabel24)
                            .addComponent(jLabel22)
                            .addComponent(jLabel21)
                            .addComponent(jLabel20)
                            .addComponent(jLabel19)
                            .addComponent(jLabel18))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(name)
                            .addComponent(age)
                            .addComponent(address)
                            .addComponent(year)
                            .addComponent(course)
                            .addComponent(xuemail)
                            .addComponent(contactno))))
                .addContainerGap(109, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton3)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel17)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel18)
                    .addComponent(name))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel19)
                    .addComponent(age))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel20)
                    .addComponent(address))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel21)
                    .addComponent(year))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel22)
                    .addComponent(course))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel23)
                    .addComponent(contactno))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel24)
                    .addComponent(xuemail))
                .addGap(63, 63, 63)
                .addComponent(jLabel25)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel26)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton3)
                .addContainerGap())
        );

        javax.swing.GroupLayout homeLayout = new javax.swing.GroupLayout(home);
        home.setLayout(homeLayout);
        homeLayout.setHorizontalGroup(
            homeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(homeLayout.createSequentialGroup()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 323, Short.MAX_VALUE))
        );
        homeLayout.setVerticalGroup(
            homeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        getContentPane().add(home, "card4");

        FillupFailed.setBackground(new java.awt.Color(37, 37, 37));

        jLabel27.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel27.setForeground(new java.awt.Color(106, 195, 161));
        jLabel27.setText("PLEASE FILL UP CORRECTLY");

        jButton4.setBackground(new java.awt.Color(37, 37, 37));
        jButton4.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jButton4.setForeground(new java.awt.Color(106, 195, 161));
        jButton4.setText("OK");
        jButton4.setActionCommand("JButton1");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout FillupFailedLayout = new javax.swing.GroupLayout(FillupFailed);
        FillupFailed.setLayout(FillupFailedLayout);
        FillupFailedLayout.setHorizontalGroup(
            FillupFailedLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(FillupFailedLayout.createSequentialGroup()
                .addGap(131, 131, 131)
                .addGroup(FillupFailedLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(FillupFailedLayout.createSequentialGroup()
                        .addGap(121, 121, 121)
                        .addComponent(jButton4))
                    .addComponent(jLabel27))
                .addContainerGap(130, Short.MAX_VALUE))
        );
        FillupFailedLayout.setVerticalGroup(
            FillupFailedLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(FillupFailedLayout.createSequentialGroup()
                .addGap(131, 131, 131)
                .addComponent(jLabel27)
                .addGap(39, 39, 39)
                .addComponent(jButton4)
                .addContainerGap(207, Short.MAX_VALUE))
        );

        getContentPane().add(FillupFailed, "card5");

        LoginFailed.setBackground(new java.awt.Color(37, 37, 37));

        jLabel28.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel28.setForeground(new java.awt.Color(255, 0, 0));
        jLabel28.setText("INPUT CREDENTIALS FAILED");

        jButton5.setBackground(new java.awt.Color(37, 37, 37));
        jButton5.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jButton5.setForeground(new java.awt.Color(106, 195, 161));
        jButton5.setText("OK");
        jButton5.setActionCommand("JButton1");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jLabel29.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel29.setForeground(new java.awt.Color(106, 195, 161));
        jLabel29.setText("PLEASE INPUT CORRECLY OR");

        jLabel30.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel30.setForeground(new java.awt.Color(106, 195, 161));
        jLabel30.setText("CREATE AN ACCOUNT");

        javax.swing.GroupLayout LoginFailedLayout = new javax.swing.GroupLayout(LoginFailed);
        LoginFailed.setLayout(LoginFailedLayout);
        LoginFailedLayout.setHorizontalGroup(
            LoginFailedLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(LoginFailedLayout.createSequentialGroup()
                .addGap(123, 123, 123)
                .addGroup(LoginFailedLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel28)
                    .addGroup(LoginFailedLayout.createSequentialGroup()
                        .addGap(33, 33, 33)
                        .addComponent(jLabel29))
                    .addGroup(LoginFailedLayout.createSequentialGroup()
                        .addGap(63, 63, 63)
                        .addComponent(jLabel30))
                    .addGroup(LoginFailedLayout.createSequentialGroup()
                        .addGap(122, 122, 122)
                        .addComponent(jButton5)))
                .addContainerGap(133, Short.MAX_VALUE))
        );
        LoginFailedLayout.setVerticalGroup(
            LoginFailedLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(LoginFailedLayout.createSequentialGroup()
                .addGap(112, 112, 112)
                .addComponent(jLabel28)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel29)
                .addGap(1, 1, 1)
                .addComponent(jLabel30)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton5)
                .addContainerGap(203, Short.MAX_VALUE))
        );

        getContentPane().add(LoginFailed, "card6");

        CSSC.setBackground(new java.awt.Color(37, 37, 37));

        jPanel5.setBackground(new java.awt.Color(106, 195, 161));

        jLabel51.setBackground(new java.awt.Color(106, 195, 161));
        jLabel51.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Sizes.png"))); // NOI18N
        jLabel51.setText("jLabel48");
        jLabel51.setOpaque(true);

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel51, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(23, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(79, 79, 79)
                .addComponent(jLabel51, javax.swing.GroupLayout.PREFERRED_SIZE, 245, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(113, Short.MAX_VALUE))
        );

        jLabel32.setBackground(new java.awt.Color(106, 195, 161));
        jLabel32.setFont(new java.awt.Font("Futura Md BT", 1, 18)); // NOI18N
        jLabel32.setForeground(new java.awt.Color(106, 195, 161));
        jLabel32.setText("COLLEGE COUNCIL UPDATES");
        jLabel32.setToolTipText("");

        jLabel33.setBackground(new java.awt.Color(106, 195, 161));
        jLabel33.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel33.setForeground(new java.awt.Color(106, 195, 161));
        jLabel33.setText("UPDATES");
        jLabel33.setToolTipText("");

        jButton6.setBackground(new java.awt.Color(106, 195, 161));
        jButton6.setFont(new java.awt.Font("The Bold Font", 1, 11)); // NOI18N
        jButton6.setForeground(new java.awt.Color(37, 37, 37));
        jButton6.setText("SEE");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jButton9.setBackground(new java.awt.Color(106, 195, 161));
        jButton9.setForeground(new java.awt.Color(37, 37, 37));
        jButton9.setText("BACK");
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });

        jLabel31.setForeground(new java.awt.Color(106, 195, 161));
        jLabel31.setText("The Computer Studies Student Council");

        jLabel34.setForeground(new java.awt.Color(106, 195, 161));
        jLabel34.setText("presents you the webinar series entitled: TechTalk.");

        jButton7.setBackground(new java.awt.Color(106, 195, 161));
        jButton7.setFont(new java.awt.Font("The Bold Font", 1, 11)); // NOI18N
        jButton7.setForeground(new java.awt.Color(37, 37, 37));
        jButton7.setText("SEE");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        jButton8.setBackground(new java.awt.Color(106, 195, 161));
        jButton8.setFont(new java.awt.Font("The Bold Font", 1, 11)); // NOI18N
        jButton8.setForeground(new java.awt.Color(37, 37, 37));
        jButton8.setText("SEE");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });

        jLabel35.setForeground(new java.awt.Color(106, 195, 161));
        jLabel35.setText("A Donation Drive for the Victims ");

        jLabel36.setForeground(new java.awt.Color(106, 195, 161));
        jLabel36.setText("of recent typhoons");

        jLabel37.setForeground(new java.awt.Color(106, 195, 161));
        jLabel37.setText("don't forget to rest!");

        jLabel38.setForeground(new java.awt.Color(106, 195, 161));
        jLabel38.setText("Exams are coming. Make sure you study hard but");

        javax.swing.GroupLayout CSSCLayout = new javax.swing.GroupLayout(CSSC);
        CSSC.setLayout(CSSCLayout);
        CSSCLayout.setHorizontalGroup(
            CSSCLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(CSSCLayout.createSequentialGroup()
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(CSSCLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(CSSCLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(CSSCLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel32)
                            .addGroup(CSSCLayout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addGroup(CSSCLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel33)
                                    .addGroup(CSSCLayout.createSequentialGroup()
                                        .addGap(10, 10, 10)
                                        .addGroup(CSSCLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(jButton7)
                                            .addComponent(jButton6)
                                            .addComponent(jButton8))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(CSSCLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel31)
                                            .addComponent(jLabel34)
                                            .addComponent(jLabel35)
                                            .addComponent(jLabel36)
                                            .addComponent(jLabel38)
                                            .addComponent(jLabel37))))))
                        .addGap(0, 12, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, CSSCLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton9)
                        .addContainerGap())))
        );
        CSSCLayout.setVerticalGroup(
            CSSCLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(CSSCLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel32, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel33, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(CSSCLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton6)
                    .addGroup(CSSCLayout.createSequentialGroup()
                        .addComponent(jLabel31)
                        .addGap(2, 2, 2)
                        .addComponent(jLabel34)))
                .addGap(18, 18, 18)
                .addGroup(CSSCLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton7)
                    .addGroup(CSSCLayout.createSequentialGroup()
                        .addComponent(jLabel35)
                        .addGap(2, 2, 2)
                        .addComponent(jLabel36)))
                .addGap(18, 18, 18)
                .addGroup(CSSCLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton8)
                    .addGroup(CSSCLayout.createSequentialGroup()
                        .addComponent(jLabel38)
                        .addGap(2, 2, 2)
                        .addComponent(jLabel37)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton9)
                .addContainerGap())
        );

        getContentPane().add(CSSC, "card7");

        CCSAdmin.setBackground(new java.awt.Color(37, 37, 37));

        jPanel6.setBackground(new java.awt.Color(106, 195, 161));

        jLabel52.setBackground(new java.awt.Color(106, 195, 161));
        jLabel52.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Sizes.png"))); // NOI18N
        jLabel52.setText("jLabel48");
        jLabel52.setOpaque(true);

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel52, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(23, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(79, 79, 79)
                .addComponent(jLabel52, javax.swing.GroupLayout.PREFERRED_SIZE, 245, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(113, Short.MAX_VALUE))
        );

        jLabel39.setBackground(new java.awt.Color(106, 195, 161));
        jLabel39.setFont(new java.awt.Font("Futura Md BT", 1, 18)); // NOI18N
        jLabel39.setForeground(new java.awt.Color(106, 195, 161));
        jLabel39.setText("COMPUTER STUDIES COLLEGE ADMIN");
        jLabel39.setToolTipText("");

        jLabel40.setBackground(new java.awt.Color(106, 195, 161));
        jLabel40.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel40.setForeground(new java.awt.Color(106, 195, 161));
        jLabel40.setText("UPDATES");
        jLabel40.setToolTipText("");

        jButton10.setBackground(new java.awt.Color(106, 195, 161));
        jButton10.setFont(new java.awt.Font("The Bold Font", 1, 11)); // NOI18N
        jButton10.setForeground(new java.awt.Color(37, 37, 37));
        jButton10.setText("SEE");
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });

        jButton11.setBackground(new java.awt.Color(106, 195, 161));
        jButton11.setForeground(new java.awt.Color(37, 37, 37));
        jButton11.setText("BACK");
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });

        jLabel41.setForeground(new java.awt.Color(106, 195, 161));
        jLabel41.setText("The Computer Studies Student Council presents you");

        jLabel42.setForeground(new java.awt.Color(106, 195, 161));
        jLabel42.setText("Wizart");

        jButton12.setBackground(new java.awt.Color(106, 195, 161));
        jButton12.setFont(new java.awt.Font("The Bold Font", 1, 11)); // NOI18N
        jButton12.setForeground(new java.awt.Color(37, 37, 37));
        jButton12.setText("SEE");
        jButton12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton12ActionPerformed(evt);
            }
        });

        jButton13.setBackground(new java.awt.Color(106, 195, 161));
        jButton13.setFont(new java.awt.Font("The Bold Font", 1, 11)); // NOI18N
        jButton13.setForeground(new java.awt.Color(37, 37, 37));
        jButton13.setText("SEE");
        jButton13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton13ActionPerformed(evt);
            }
        });

        jLabel43.setForeground(new java.awt.Color(106, 195, 161));
        jLabel43.setText("Hello XU Ateneans!");

        jLabel44.setForeground(new java.awt.Color(106, 195, 161));
        jLabel44.setText("Finals are fast approaching! Be sure to check...");

        jLabel45.setForeground(new java.awt.Color(106, 195, 161));
        jLabel45.setText("this year's midterm tutors");

        jLabel46.setForeground(new java.awt.Color(106, 195, 161));
        jLabel46.setText("CSSC would like to apperiacte the efforts of");

        javax.swing.GroupLayout CCSAdminLayout = new javax.swing.GroupLayout(CCSAdmin);
        CCSAdmin.setLayout(CCSAdminLayout);
        CCSAdminLayout.setHorizontalGroup(
            CCSAdminLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(CCSAdminLayout.createSequentialGroup()
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(CCSAdminLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(CCSAdminLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(CCSAdminLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel39)
                            .addGroup(CCSAdminLayout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addGroup(CCSAdminLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel40)
                                    .addGroup(CCSAdminLayout.createSequentialGroup()
                                        .addGap(10, 10, 10)
                                        .addGroup(CCSAdminLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(jButton12)
                                            .addComponent(jButton10)
                                            .addComponent(jButton13))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(CCSAdminLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel41)
                                            .addComponent(jLabel42)
                                            .addComponent(jLabel43)
                                            .addComponent(jLabel44)
                                            .addComponent(jLabel46)
                                            .addComponent(jLabel45))))))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, CCSAdminLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton11)
                        .addContainerGap())))
        );
        CCSAdminLayout.setVerticalGroup(
            CCSAdminLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(CCSAdminLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel39, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel40, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(CCSAdminLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton10)
                    .addGroup(CCSAdminLayout.createSequentialGroup()
                        .addComponent(jLabel41)
                        .addGap(2, 2, 2)
                        .addComponent(jLabel42)))
                .addGap(18, 18, 18)
                .addGroup(CCSAdminLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton12)
                    .addGroup(CCSAdminLayout.createSequentialGroup()
                        .addComponent(jLabel43)
                        .addGap(2, 2, 2)
                        .addComponent(jLabel44)))
                .addGap(18, 18, 18)
                .addGroup(CCSAdminLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton13)
                    .addGroup(CCSAdminLayout.createSequentialGroup()
                        .addComponent(jLabel46)
                        .addGap(2, 2, 2)
                        .addComponent(jLabel45)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton11)
                .addContainerGap())
        );

        getContentPane().add(CCSAdmin, "card7");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnCreateAccActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCreateAccActionPerformed
        // TODO add your handling code here:
        login.hide();
        createacc.show();
    }//GEN-LAST:event_btnCreateAccActionPerformed

    private void unameTFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_unameTFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_unameTFActionPerformed

    private void passwordTFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_passwordTFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_passwordTFActionPerformed

    private void xuemailTFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_xuemailTFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_xuemailTFActionPerformed

    private void firstnameTFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_firstnameTFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_firstnameTFActionPerformed

    private void btnSubmitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSubmitActionPerformed
        try {
            // TODO add your handling code here:
            String username = unameTF.getText();
            String password = passwordTF.getText();
            String xuemail = xuemailTF.getText();
            String firstname = firstnameTF.getText();
            String lastname = lastnameTF.getText();
            String middleinitial = middleinitialTF.getText();
            int age = Integer.parseInt(ageTF.getText());  
            String address = addressTF.getText();
            int contactno = Integer.parseInt(contactnoTF.getText());
            //getting informations from the Texfields
            
            Statement stmt = (Statement) con.createStatement();
            
            String dbop = "INSERT INTO PERSONALINFO (username,password,xuemail,firstname,lastname,middleinitial,age,address,contactno,gender,year,course) VALUES('"+username+"','"+password+"','"+xuemail+"','"+firstname+"','"+lastname+"','"+middleinitial+"','"+age+"','"+address+"','"+contactno+"','"+Gender+"','"+Year+"','"+Course+"')";
            //creating a query to the Database          
            stmt.execute(dbop);           
            stmt.close();
            
            login.show();
            createacc.hide();
        } catch (SQLException ex) {
            Logger.getLogger(Wizspace.class.getName()).log(Level.SEVERE, null, ex);
            FillupFailed.show();
            createacc.hide();
        }
    }//GEN-LAST:event_btnSubmitActionPerformed

    private void btnYearIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnYearIActionPerformed
        // TODO add your handling code here:
        Year = "I";
    }//GEN-LAST:event_btnYearIActionPerformed

    private void btnYearIIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnYearIIActionPerformed
        // TODO add your handling code here:
        Year = "II";
    }//GEN-LAST:event_btnYearIIActionPerformed

    private void btnYearIIIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnYearIIIActionPerformed
        // TODO add your handling code here:
        Year = "III";
    }//GEN-LAST:event_btnYearIIIActionPerformed

    private void btnYearIVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnYearIVActionPerformed
        // TODO add your handling code here:
        Year = "IV";
    }//GEN-LAST:event_btnYearIVActionPerformed

    private void btnBSCSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBSCSActionPerformed
        // TODO add your handling code here:
        Course = "BSCS";
    }//GEN-LAST:event_btnBSCSActionPerformed

    private void btnBSISActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBSISActionPerformed
        // TODO add your handling code here:
        Course = "BSIS";
    }//GEN-LAST:event_btnBSISActionPerformed

    private void btnBSITActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBSITActionPerformed
        // TODO add your handling code here:
        Course = "BSIT";
    }//GEN-LAST:event_btnBSITActionPerformed

    private void btnLoginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLoginActionPerformed
        // TODO add your handling code here:
        Statement stmt;
      /* These following lines are processing the log in phase of the program
        * It basically communicates with the database in verifying information
        * and the codes to display the stored information from the database to the 
        * homescreen of the program
        */
        try {
            stmt = con.createStatement();
            //Communicating with the database through this line of code
            ResultSet rs = stmt.executeQuery("SELECT * FROM personalinfo");
            while(rs.next()){
                String unamedb = rs.getString("username");
                String unamelogin = loginunameTF.getText();
                if (unamelogin.equals(unamedb)){
                    rs = stmt.executeQuery("SELECT * FROM personalinfo");
                    while(rs.next()){
                        String passworddb = rs.getString("password");
                        String loginpass = loginpasswordTF.getText();
                        if (loginpass.equals(passworddb)){
                            login.hide();
                            home.show();
                            LoginFailed.hide();
                            rs = stmt.executeQuery("SELECT * FROM personalinfo WHERE username = '"+unamelogin+"'");
                            while(rs.next()){
                                String fnameDB = rs.getString("firstname");
                                String lnameDB = rs.getString("lastname");
                                String middleinitialDB = rs.getString("middleinitial");
                                name.setText(fnameDB+" "+middleinitialDB+". "+lnameDB+"");
                                String ageDB = rs.getString("age");
                                age.setText(ageDB);
                                String addressDB = rs.getString("address");
                                address.setText(addressDB);
                                String yearDB = rs.getString("year");
                                year.setText(yearDB);
                                String courseDB = rs.getString("course");
                                course.setText(courseDB);
                                String contactDB = rs.getString("contactno");
                                contactno.setText(contactDB);
                                String xuemailDB = rs.getString("xuemail");
                                System.out.print(xuemailDB);
                                xuemail.setText(xuemailDB);
                            }
                        }
                        else{ 
                            login.hide();
                            LoginFailed.show();
                        }
                    }
                }
                else{ 
                    login.hide();
                    LoginFailed.show();
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(Wizspace.class.getName()).log(Level.SEVERE, null, ex);
            login.hide();
            LoginFailed.show();
        }                    
    }//GEN-LAST:event_btnLoginActionPerformed

    private void btnMaleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMaleActionPerformed
        // TODO add your handling code here:
        Gender = "Male";
    }//GEN-LAST:event_btnMaleActionPerformed

    private void btnFemaleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFemaleActionPerformed
        // TODO add your handling code here:
        Gender = "Female";
    }//GEN-LAST:event_btnFemaleActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
        createacc.show();
        FillupFailed.hide();
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // TODO add your handling code here:
        login.show();
        LoginFailed.hide();
    }//GEN-LAST:event_jButton5ActionPerformed
    //These following lines of codes are displaying updates and providing a link to the websites 
    //to see all the informations
    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        // TODO add your handling code here:
        try{
                    String URL = "https://www.facebook.com/XU.CSSC/photos/a.220409744644186/3744881142197011/";
                    java.awt.Desktop.getDesktop().browse(java.net.URI.create(URL));
                }
                catch (Exception e){
                    JOptionPane.showMessageDialog(null, e.getMessage());
    }//GEN-LAST:event_jButton6ActionPerformed
    }
    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        // TODO add your handling code here:
         try{
                    String URL = "https://www.facebook.com/XU.CSSC/photos/pcb.3813641231987668/3813639495321175/";
                    java.awt.Desktop.getDesktop().browse(java.net.URI.create(URL));
                }
                catch (Exception e){
                    JOptionPane.showMessageDialog(null, e.getMessage());
    }
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        // TODO add your handling code here:
        try{
                    String URL = "https://www.facebook.com/XU.CSSC/photos/a.220409744644186/3811140305571094/";
                    java.awt.Desktop.getDesktop().browse(java.net.URI.create(URL));
                }
                catch (Exception e){
                    JOptionPane.showMessageDialog(null, e.getMessage());
    }
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
        // TODO add your handling code here:
        CSSC.hide();
        home.show();
    }//GEN-LAST:event_jButton9ActionPerformed
     //These following lines of codes are displaying updates and providing a link to the websites 
     //to see all the informations
    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
        // TODO add your handling code here:
        try{
                    String URL = "https://www.facebook.com/XU.CSSC/photos/a.220409744644186/3808218209196637/";
                    java.awt.Desktop.getDesktop().browse(java.net.URI.create(URL));
                }
                catch (Exception e){
                    JOptionPane.showMessageDialog(null, e.getMessage());
    }
    }//GEN-LAST:event_jButton10ActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
        // TODO add your handling code here:
        CCSAdmin.hide();
        home.show();
    }//GEN-LAST:event_jButton11ActionPerformed

    private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton12ActionPerformed
        // TODO add your handling code here:
        try{
                    String URL = "https://www.facebook.com/XUSTRAW.OFFICIAL/photos/a.575656132963367/926437644551879/";
                    java.awt.Desktop.getDesktop().browse(java.net.URI.create(URL));
                }
                catch (Exception e){
                    JOptionPane.showMessageDialog(null, e.getMessage());
    }
    }//GEN-LAST:event_jButton12ActionPerformed

    private void jButton13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton13ActionPerformed
        // TODO add your handling code here:
        try{
                    String URL = "https://www.facebook.com/XU.CSSC/photos/a.220409744644186/3728681920483600";
                    java.awt.Desktop.getDesktop().browse(java.net.URI.create(URL));
                }
                catch (Exception e){
                    JOptionPane.showMessageDialog(null, e.getMessage());
    }
    }//GEN-LAST:event_jButton13ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        login.show();
        home.hide();
        LoginFailed.hide();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        CCSAdmin.show();
        home.hide();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        home.hide();
        CSSC.show();
    }//GEN-LAST:event_jButton1ActionPerformed
    
        
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Wizspace.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Wizspace.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Wizspace.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Wizspace.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* These lines will create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Wizspace().setVisible(true);
            }
        });
    }
    //These lines allows the program to establish a connection between the system and the Database
    void createConnection(){
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/wizspacedb?useTimezone=true&serverTimezone=UTC","root","itcc");
            System.out.print("DATABASE CONNECTED");
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Wizspace.class.getName()).log(Level.SEVERE, null, ex);
            System.out.print("DATABASE NOT CONNECTED");
        }
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel CCSAdmin;
    private javax.swing.JPanel CSSC;
    private javax.swing.JPanel FillupFailed;
    private javax.swing.JPanel LoginFailed;
    private javax.swing.JLabel address;
    private javax.swing.JTextField addressTF;
    private javax.swing.JLabel age;
    private javax.swing.JTextField ageTF;
    private javax.swing.JButton btnBSCS;
    private javax.swing.JButton btnBSIS;
    private javax.swing.JButton btnBSIT;
    private javax.swing.JButton btnCreateAcc;
    private javax.swing.JButton btnFemale;
    private javax.swing.JButton btnLogin;
    private javax.swing.JButton btnMale;
    private javax.swing.JButton btnSubmit;
    private javax.swing.JButton btnYearI;
    private javax.swing.JButton btnYearII;
    private javax.swing.JButton btnYearIII;
    private javax.swing.JButton btnYearIV;
    private javax.swing.JLabel contactno;
    private javax.swing.JTextField contactnoTF;
    private javax.swing.JLabel course;
    private javax.swing.JPanel createacc;
    private javax.swing.JTextField firstnameTF;
    private javax.swing.JPanel home;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton13;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel52;
    private javax.swing.JLabel jLabel53;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JTextField lastnameTF;
    private javax.swing.JPanel login;
    private javax.swing.JPasswordField loginpasswordTF;
    private javax.swing.JTextField loginunameTF;
    private javax.swing.JTextField middleinitialTF;
    private javax.swing.JLabel name;
    private javax.swing.JTextField passwordTF;
    private javax.swing.JTextField unameTF;
    private javax.swing.JLabel xuemail;
    private javax.swing.JTextField xuemailTF;
    private javax.swing.JLabel year;
    // End of variables declaration//GEN-END:variables
}
